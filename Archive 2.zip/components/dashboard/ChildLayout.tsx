"use client";

import ChildFooter from "./ChildFooter";
import ChildSidebar from "./ChildSidebar";

type ChildLayoutProps = {
  profile: any;
  activeHref?: string;
  children: React.ReactNode;
};

export default function ChildLayout({
  profile,
  activeHref = "/dashboard",
  children,
}: ChildLayoutProps) {
  return (
    <main dir="rtl" className="relative min-h-screen overflow-hidden text-[#211B4C]">
      {/* الخلفية */}
      <div
        className="pointer-events-none fixed inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/images/waei-child/bg-wide.png')",
          filter: "saturate(55%) brightness(1.08) blur(2px)",
          transform: "scale(1.04)",
        }}
      />

      {/* طبقة تفتيح */}
      <div className="pointer-events-none fixed inset-0 bg-white/28" />

      {/* طبقة بنفسجية خفيفة عشان تناسب الواجهة */}
      <div className="pointer-events-none fixed inset-0 bg-gradient-to-br from-white/20 via-transparent to-[#6E46E8]/10" />

      <div className="relative z-10 flex min-h-screen">
        <ChildSidebar profile={profile} activeHref={activeHref} />

        <div className="min-w-0 flex min-h-screen flex-1 flex-col">
          <div className="flex-1">{children}</div>
          <ChildFooter />
        </div>
      </div>
    </main>
  );
}