"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { getFileUrl } from "@/lib/files";
import ChildLayout from "@/components/dashboard/ChildLayout";
import { getChildAvatar, getChildName, isProActive } from "@/components/dashboard/childUtils";

type Program = {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  age_range: string | null;
  access_type: string | null;
  sort_order: number;
  categories?: { name: string } | null;
};

type Attempt = {
  id: string;
  program_id: string | null;
  content_id: string | null;
  completed: boolean;
  score: number | null;
  max_score: number | null;
  percentage: number | null;
  created_at: string;
};

const icon = (name: string) => `/images/waei-child/icons/${name}-3d.svg`;
const fallbackProgramIcons = ["🏝️", "🏰", "🚀", "🎈", "⛰️", "🌈"];
const fallbackGradients = [
  "from-[#22C7A9] to-[#4DA3FF]",
  "from-[#FF4F76] to-[#FFB347]",
  "from-[#4423B8] to-[#6C63FF]",
  "from-[#FF8A00] to-[#FFD166]",
  "from-[#2A3556] to-[#7464C8]",
  "from-[#42BFA8] to-[#B2F06A]",
];

export default function ChildDashboard({ profile }: { profile: any }) {
  const [programs, setPrograms] = useState<Program[]>([]);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [loading, setLoading] = useState(true);
  const [localAccessCode, setLocalAccessCode] = useState(profile?.access_code || "");

  const childName = getChildName(profile);
  const childAvatar = getChildAvatar(profile);
  const proActive = isProActive(profile);

  useEffect(() => {
    loadData();
    ensureAccessCode();
  }, []);

  async function ensureAccessCode() {
    if (profile?.access_code) {
      setLocalAccessCode(profile.access_code);
      return;
    }

    const generatedCode = Math.random().toString(36).slice(2, 8).toUpperCase();
    setLocalAccessCode(generatedCode);

    await supabase.from("profiles").update({ access_code: generatedCode }).eq("id", profile.id);
  }

  async function copyAccessCode() {
    if (!localAccessCode) return;
    await navigator.clipboard.writeText(localAccessCode);
    alert("تم نسخ كود الربط ✅");
  }

  async function loadData() {
    setLoading(true);

    const { data: programsData } = await supabase
      .from("programs")
      .select("*, categories(name)")
      .eq("is_published", true)
      .or("is_deleted.is.null,is_deleted.eq.false")
      .order("sort_order", { ascending: true });

    const { data: attemptsData } = await supabase
      .from("game_attempts")
      .select("*")
      .eq("child_profile_id", profile.id)
      .eq("completed", true)
      .order("created_at", { ascending: false });

    setPrograms((programsData as Program[]) || []);
    setAttempts((attemptsData as Attempt[]) || []);
    setLoading(false);
  }

  function isProgramCompleted(programId: string) {
    return attempts.some((attempt) => attempt.program_id === programId && attempt.completed);
  }

  function getProgramBestScore(programId: string) {
    const percentages = attempts
      .filter((attempt) => attempt.program_id === programId)
      .map((attempt) => attempt.percentage || 0)
      .filter((value) => value > 0);

    if (!percentages.length) return null;
    return Math.max(...percentages);
  }

  function getProgramHref(program: Program) {
    const locked = program.access_type === "pro" && !proActive;
    return locked ? "/plans" : `/child/programs/${program.slug}`;
  }

  const completedPrograms = useMemo(
    () => programs.filter((program) => isProgramCompleted(program.id)).length,
    [programs, attempts]
  );

  const totalXp = useMemo(() => {
    return attempts.reduce((sum, attempt) => {
      const percentage = attempt.percentage || 0;
      if (percentage >= 90) return sum + 150;
      if (percentage >= 70) return sum + 120;
      if (percentage > 0) return sum + 100;
      return sum;
    }, 0);
  }, [attempts]);

  const displayXp = profile?.xp ?? totalXp;
  const lastAttempt = attempts[0];

  return (
    <ChildLayout profile={profile} activeHref="/dashboard">
      <section className="relative flex-1 px-3 py-5 md:px-7 md:py-7">
        <div className="relative mx-auto max-w-7xl">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex rounded-[2rem] border border-white/35 bg-white/80 p-2 shadow-[0_20px_55px_rgba(50,55,120,.16)] backdrop-blur-xl">
              <Link href="/dashboard/leaderboard" className="rounded-[1.5rem] bg-gradient-to-l from-[#4f3ad5] to-[#7f67ff] px-7 py-4 font-black text-white shadow-lg">
                ترتيبي 🏆
              </Link>
              <Link href={proActive ? "/dashboard/subscription" : "/plans"} className="rounded-[1.5rem] bg-gradient-to-l from-[#FFEBA5] to-[#FFF6CE] px-7 py-4 font-black text-[#9a5a00] shadow-lg">
                Pro 👑 <span className="block text-sm">اشتراك</span>
              </Link>
            </div>

            <div className="relative overflow-hidden rounded-[2.5rem] border border-white/45 bg-white/82 px-10 py-6 text-center shadow-[0_25px_70px_rgba(60,80,130,.18)] backdrop-blur-xl md:min-w-[420px]">
              <p className="font-black text-[#23b892]">أهلاً بك 👋</p>
              <h1 className="mt-1 text-5xl font-black text-[#201866] md:text-6xl">يا {childName}</h1>
              <p className="mt-3 font-bold text-[#30306d]">اختر برنامجك وابدأ رحلة جديدة اليوم.</p>
            </div>
          </div>

          <section className="relative mb-5 overflow-hidden rounded-[2.5rem] border border-white/25 bg-gradient-to-l from-[#4b2ac2]/96 via-[#633be0]/96 to-[#6f47ef]/96 p-6 text-white shadow-[0_24px_70px_rgba(60,34,160,.36)]">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_25%_55%,rgba(255,255,255,.23),transparent_13%),radial-gradient(circle_at_88%_58%,rgba(255,214,90,.40),transparent_11%)]" />
            <div className="relative flex flex-wrap items-center justify-between gap-6">
              <div className="rounded-[1.8rem] bg-white px-8 py-5 text-center shadow-2xl">
                <div className="text-sm font-black text-[#6042df]">كود الربط</div>
                <div className="mt-2 text-5xl font-black tracking-[0.25em] text-[#4b35b8]">
                  {localAccessCode || "------"}
                </div>
                <button type="button" onClick={copyAccessCode} className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#6042df]/12 px-6 py-3 text-sm font-black text-[#6042df]">
                  <img src={icon("programs")} alt="" className="h-6 w-6" />
                  نسخ الكود
                </button>
              </div>

              <div className="max-w-2xl text-center md:text-right">
                <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-sm font-black">
                  🔗 ربط ولي الأمر
                </div>
                <h2 className="text-3xl font-black md:text-4xl">شارك هذا الكود مع ولي أمرك</h2>
                <p className="mt-3 text-sm font-bold leading-7 text-white/88">
                  يمكن لولي الأمر إدخال هذا الكود لربط حسابك ومتابعة تقدمك وبرامجك.
                </p>
              </div>

              <img src={icon("star")} alt="" className="hidden h-28 w-28 md:block" />
            </div>
          </section>

          {!proActive && (
            <section className="mb-5 rounded-[2.2rem] border border-white/30 bg-[#fff4c7]/92 p-5 shadow-lg backdrop-blur-xl">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-[#211B4C]">برامج مميزة بانتظارك 👑</h2>
                  <p className="mt-2 font-bold text-[#8A6200]">بعض البرامج تحتاج اشتراك Pro. يمكنك مشاهدة البرامج، لكن الدخول إلى محتوى Pro يتطلب تفعيل الاشتراك.</p>
                </div>
                <Link href="/plans" className="rounded-full bg-[#4b35b8] px-7 py-4 font-black text-white shadow-lg">مشاهدة الخطط والاشتراكات</Link>
              </div>
            </section>
          )}

          <div className="mb-5 grid gap-4 md:grid-cols-3">
            <StatCard icon="book" value={programs.length} label="برامج متاحة" tone="from-[#dcedff]/95 to-[#ffffff]/90 text-[#173887]" />
            <StatCard icon="shield" value={completedPrograms} label="برامج مكتملة" tone="from-[#dcffd5]/95 to-[#ffffff]/90 text-[#16812b]" />
            <StatCard icon="xp" value={displayXp} label="XP المكتسب" tone="from-[#fff0b8]/95 to-[#ffffff]/90 text-[#b85b00]" />
          </div>

          <section className="mb-5 rounded-[2.4rem] border border-white/35 bg-white/86 p-5 shadow-[0_25px_70px_rgba(42,54,120,.15)] backdrop-blur-xl">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
              <h2 className="flex items-center gap-3 text-3xl font-black text-[#211B4C]">
                <img src={icon("programs")} alt="" className="h-12 w-12" />
                برامجي
              </h2>
              <Link href="/child/programs" className="rounded-full bg-[#7050e8] px-6 py-3 font-black text-white shadow-lg">عرض الكل</Link>
            </div>

            {loading ? (
              <div className="rounded-[2rem] bg-white p-12 text-center font-black text-[#6E7A99]">جاري تحميل البرامج...</div>
            ) : programs.length > 0 ? (
              <div className={`grid gap-5 ${programs.length === 1 ? "mx-auto max-w-[360px]" : programs.length === 2 ? "mx-auto max-w-3xl md:grid-cols-2" : "sm:grid-cols-2 xl:grid-cols-4"}`}>
                {programs.slice(0, 6).map((program, index) => {
                  const completed = isProgramCompleted(program.id);
                  const bestScore = getProgramBestScore(program.id);
                  const locked = program.access_type === "pro" && !proActive;

                  return (
                    <Link key={program.id} href={getProgramHref(program)} className="group overflow-hidden rounded-[1.8rem] bg-white shadow-xl transition hover:-translate-y-2">
                      <div className={`relative h-44 overflow-hidden bg-gradient-to-br ${fallbackGradients[index % fallbackGradients.length]}`}>
                        {program.image_url ? (
                          <img src={getFileUrl(program.image_url)} alt={program.title} className={`h-full w-full object-cover ${locked ? "opacity-75" : ""}`} />
                        ) : (
                          <div className="grid h-full place-items-center text-7xl">{fallbackProgramIcons[index % fallbackProgramIcons.length]}</div>
                        )}

                        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/45 to-transparent" />

                        {completed && <div className="absolute left-4 top-4 rounded-full bg-[#42BFA8] px-4 py-2 text-sm font-black text-white shadow-lg">✅ مكتمل</div>}
                        {locked && (
                          <div className="absolute inset-0 flex items-center justify-center bg-[#211B4C]/45 backdrop-blur-[1px]">
                            <div className="rounded-2xl bg-white px-4 py-3 text-center font-black text-[#211B4C] shadow-xl">Pro 🔒</div>
                          </div>
                        )}
                        {bestScore !== null && <div className="absolute bottom-3 right-3 rounded-full bg-white/95 px-4 py-2 text-sm font-black text-[#211B4C] shadow-lg">{bestScore}%</div>}
                      </div>

                      <div className="p-5">
                        <div className="mb-3 flex flex-wrap gap-2">
                          {program.categories?.name && <span className="rounded-full bg-[#D9F5EE] px-3 py-1.5 text-xs font-black text-[#0B4D6B]">{program.categories.name}</span>}
                          <span className={`rounded-full px-3 py-1.5 text-xs font-black ${program.access_type === "pro" ? "bg-yellow-100 text-yellow-700" : "bg-green-100 text-green-700"}`}>{program.access_type === "pro" ? "👑 Pro" : "مجاني"}</span>
                        </div>
                        <h3 className="text-2xl font-black text-[#211B4C]">{program.title}</h3>
                        {program.description && <p className="mt-2 line-clamp-2 leading-7 text-[#5F5A7B]">{program.description}</p>}
                        <span className="mt-4 inline-flex rounded-full bg-[#42BFA8] px-6 py-3 font-black text-white shadow-lg">{locked ? "فعّل اشتراكك" : completed ? "إعادة البرنامج" : "ابدأ الآن"}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-[2rem] border-2 border-dashed border-[#DDEDEA] bg-white p-12 text-center">
                <h3 className="text-3xl font-black text-[#211B4C]">لا توجد برامج منشورة حاليًا</h3>
              </div>
            )}
          </section>

          {lastAttempt && (
            <section className="overflow-hidden rounded-[2.2rem] border border-white/35 bg-white/86 p-5 shadow-xl backdrop-blur-xl">
              <div className="flex flex-wrap items-center justify-between gap-5">
                <div className="flex items-center gap-4">
                  <img src={icon("dragon")} alt="" className="hidden h-28 w-28 md:block" />
                  <div>
                    <p className="font-black text-[#42BFA8]">آخر نشاط</p>
                    <h2 className="mt-1 text-3xl font-black text-[#211B4C]">نتيجتك الأخيرة: {lastAttempt.score ?? 0} / {lastAttempt.max_score ?? "-"}</h2>
                    <p className="mt-2 font-bold text-[#4C4A73]">استمر، كل محاولة تقرّبك من إنجاز جديد.</p>
                  </div>
                </div>
                <div className="grid h-28 w-28 place-items-center rounded-full bg-white text-3xl font-black text-[#42BFA8] shadow-lg ring-8 ring-[#E7FBF4]">{lastAttempt.percentage ?? 0}%</div>
              </div>
            </section>
          )}
        </div>
      </section>
    </ChildLayout>
  );
}

function StatCard({ icon: iconName, value, label, tone }: { icon: string; value: number; label: string; tone: string }) {
  return (
    <div className={`relative overflow-hidden rounded-[2rem] border border-white/45 bg-gradient-to-br ${tone} p-5 shadow-xl backdrop-blur-xl`}>
      <img src={icon(iconName)} alt="" className="absolute right-5 top-1/2 h-28 w-28 -translate-y-1/2" />
      <div className="relative mr-32">
        <div className="text-5xl font-black">{value}</div>
        <div className="mt-2 font-black">{label}</div>
      </div>
      <img src={icon("star")} alt="" className="absolute left-5 top-5 h-10 w-10 opacity-35" />
    </div>
  );
}
